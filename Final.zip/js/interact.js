
    
    $(document).on('click', function (e) {
 var audio = new Audio('/sounds/ui/taps/tap-muted.mp3'); 
audio.play();
});